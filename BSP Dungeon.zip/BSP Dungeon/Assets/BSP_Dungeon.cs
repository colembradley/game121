﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Text;

public class DungeonTile
{
    public string contents;
    public DungeonTile()
    {
        contents = "empty";
    }
}

public class Partition
{
    public int width;
    public int height;
    public int positionX;
    public int positionY;
    public Partition(){}
    public Partition(int inputWidth, int inputHeight, int inputPositionX, int inputPositionY)
    {
        width = inputWidth;
        height = inputHeight;
        positionX = inputPositionX;
        positionY = inputPositionY;
    }
}

public class Room
{
    public int width;
    public int height;
    public int positionX;
    public int positionY;
    public Room() { }
    public Room(int inputLength, int inputWidth, int inputPositionX, int inputPositionY)
    {
        width = inputLength;
        height = inputWidth;
        positionX = inputPositionX;
        positionY = inputPositionY;
    }
}

public class BSP_Dungeon : MonoBehaviour {

    public int width = 20;
    public int height = 20;
    public DungeonTile[,] game;
    public List<Partition> partitions;
    public List<Room> rooms;

    void Start () {
        game = new DungeonTile[width,height];
        partitions = new List<Partition>();
        rooms = new List<Room>();
        Initialize();
        //Split();
        MakeRooms();
        RenderGame();
        ConnectHorizontal(rooms[0], rooms[1], true);
        PrintGame();
    }

    void Initialize()
    {
        for (int i = 0; i < game.GetLength(0); i++)
        {
            for (int j = 0; j < game.GetLength(1); j++)
            {
                game[i, j] = new DungeonTile();
            }
        }
    }

    void Split()
    {
        partitions.Add(new Partition(width/2, height, 0, 0));
        if (width % 2 == 0)
        {
            partitions.Add(new Partition(width / 2, height, width / 2, 0));
        }
        else
        {
            partitions.Add(new Partition((width / 2) + 1, height, width / 2, 0));
        }
    }

    void MakeRooms()
    {
        for (int i = 0; i < partitions.Count; i++)
        {
            rooms.Add(new Room(partitions[i].width-2, partitions[i].height-2,
                        partitions[i].positionX+1, partitions[i].positionY+1));
        }
    }

    void ConnectHorizontal(Room room1, Room room2, bool random)
    {
        List<int> solutions = new List<int>();

        for (int i = 0; i < room1.height; i++)
        {
            for (int j = 0; j < room2.height; j++)
            {
                if(room2.positionY+j == room1.positionY + i)
                {
                    solutions.Add(room2.positionY + i);
                }
            }
        }

        if (random)
        {
            int location = solutions[Random.Range(0, solutions.Count)];
            game[room2.positionX - 1, location].contents = "corridor";
            game[room2.positionX - 2, location].contents = "corridor";
        }
        else
        {
            int location = solutions[(solutions.Count / 2) - 1];
            game[room2.positionX - 1, location].contents = "corridor";
            game[room2.positionX - 2, location].contents = "corridor";
        }
    }

    void RenderGame()
    {
        for (int i = 0; i < rooms.Count; i++)
        {
            for (int j = 0; j < game.GetLength(0); j++)
            {
                for (int k = 0; k < game.GetLength(1); k++)
                {
                    if (j < rooms[i].width + rooms[i].positionX &&
                        j >= rooms[i].positionX &&
                        k < rooms[i].height + rooms[i].positionY &&
                        k >= rooms[i].positionY)
                    {
                        game[j, k].contents = "room";
                    }
                }
            }
        }
    }

    void PrintGame()
    {
        StringBuilder gameString = new StringBuilder();
        for (int i = 0; i < game.GetLength(0); i++)
        {
            StringBuilder line = new StringBuilder();
            for (int j = 0; j < game.GetLength(1); j++)
            {
                if(game[j, i].contents == "empty")
                {
                    line.Append("E ");
                }
                else if (game[j, i].contents == "room")
                {
                    line.Append("R ");
                }
                else if (game[j, i].contents == "corridor")
                {
                    line.Append("C ");
                }
            }
            gameString.AppendLine(line.ToString());
        }
        print(gameString.ToString());
    }
}
