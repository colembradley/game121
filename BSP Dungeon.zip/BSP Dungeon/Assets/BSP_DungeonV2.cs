﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Text;
using Assets;

public class BSP_DungeonV2 : MonoBehaviour {

    public int width = 20;
    public int height = 20;
    public int splits = 2;
    public DungeonTile[,] game;
    public List<Partition> partitions;
    public List<Partition> corridors;
    public List<Room> rooms;

    void Start () {
        BinaryTree<RectInt> sampleRectTree;
        sampleRectTree = new BinaryTree<RectInt>(new RectInt(0, 0, width, height));

        game = new DungeonTile[width,height];
        partitions = new List<Partition>();
        rooms = new List<Room>();
        Subdivide(sampleRectTree, true, splits);
        
        Initialize();
        //Split();

        MakeRooms();
        MakeCorridors(sampleRectTree);
        RenderGame();
        PrintGame();
    }

    void Initialize()
    {
        for (int i = 0; i < game.GetLength(0); i++)
        {
            for (int j = 0; j < game.GetLength(1); j++)
            {
                game[i, j] = new DungeonTile();
            }
        }
    }

    void Split()
    {
        partitions.Add(new Partition(width/2, height, 0, 0));
        if (width % 2 == 0)
        {
            partitions.Add(new Partition(width / 2, height, width / 2, 0));
        }
        else
        {
            partitions.Add(new Partition((width / 2) + 1, height, width / 2, 0));
        }
    }

    void MakeRooms()
    {
        for (int i = 0; i < partitions.Count; i++)
        {
            rooms.Add(new Room(partitions[i].width-2, partitions[i].height-2,
                        partitions[i].positionX+1, partitions[i].positionY+1));
        }
    }

    /*
    void ConnectHorizontal(Room room1, Room room2, bool random)
    {
        List<int> solutions = new List<int>();

        for (int i = 0; i < room1.height; i++)
        {
            for (int j = 0; j < room2.height; j++)
            {
                if(room2.positionY+j == room1.positionY + i)
                {
                    solutions.Add(room2.positionY + i);
                }
            }
        }

        if (random)
        {
            int location = solutions[Random.Range(0, solutions.Count)];
            game[room2.positionX - 1, location].contents = "corridor";
            game[room2.positionX - 2, location].contents = "corridor";
        }
        else
        {
            int location = solutions[(solutions.Count / 2) - 1];
            game[room2.positionX - 1, location].contents = "corridor";
            game[room2.positionX - 2, location].contents = "corridor";
        }
    }

    void ConnectHorizontal(Partition room1, Partition room2, bool random)
    {
        List<int> solutions = new List<int>();

        for (int i = 0; i < room1.height; i++)
        {
            for (int j = 0; j < room2.height; j++)
            {
                if (room2.positionY + j == room1.positionY + i)
                {
                    solutions.Add(room2.positionY + i);
                }
            }
        }

        if (random)
        {
            int location = solutions[Random.Range(0, solutions.Count)];
            game[room2.positionX - 1, location].contents = "corridor";
            game[room2.positionX - 2, location].contents = "corridor";
        }
        else
        {
            int location = solutions[(solutions.Count / 2) - 1];
            game[room2.positionX - 1, location].contents = "corridor";
            game[room2.positionX - 2, location].contents = "corridor";
        }
    }
    */

    bool ConnectHorizontal(BinaryTreeNode<RectInt> room1, BinaryTreeNode<RectInt> room2, bool random)
    {
        List<int> solutions = new List<int>();

        for (int i = 0; i < room1.Value().height; i++)
        {
            for (int j = 0; j < room2.Value().height; j++)
            {
                if (room2.Value().y + j == room1.Value().y + i)
                {
                    solutions.Add(room2.Value().y + i);
                }
            }
        }

        if (solutions.Count > 0)
        {
            if (random)
            {
                int location = solutions[Random.Range(0, solutions.Count)];
                game[room2.Value().x - 1, location].contents = "corridor";
                game[room2.Value().x - 2, location].contents = "corridor";
            }
            else
            {
                int location = solutions[(solutions.Count)-2];
                game[room2.Value().x, location].contents = "corridor";
                game[room2.Value().x - 1, location].contents = "corridor";
            }
            return true;
        }
        else
        {
            return false;
        }
    }

    bool ConnectVertical(BinaryTreeNode<RectInt> room1, BinaryTreeNode<RectInt> room2, bool random)
    {
        List<int> solutions = new List<int>();

        for (int i = 0; i < room1.Value().width; i++)
        {
            for (int j = 0; j < room2.Value().width; j++)
            {
                if (room2.Value().x + j == room1.Value().x + i)
                {
                    solutions.Add(room2.Value().x + i);
                }
            }
        }

        if (solutions.Count > 0)
        {
            if (random)
            {
                int location = solutions[Random.Range(0, solutions.Count)];
                game[room2.Value().x - 1, location].contents = "corridor";
                game[room2.Value().x - 2, location].contents = "corridor";
            }
            else
            {
                int location = solutions[(solutions.Count) - 2];
                game[location, room2.Value().y].contents = "corridor";
                game[location, room2.Value().y - 1].contents = "corridor";
            }
            return true;
        }
        else
        {
            return false;
        }
    }

    /*
    void ConnectVertical(BinaryTreeNode<RectInt> room1, BinaryTreeNode<RectInt> room2, bool random)
    {
        List<int> solutions = new List<int>();

        for (int i = 0; i < room1.Value().width; i++)
        {
            for (int j = 0; j < room2.Value().width; j++)
            {
                if (room2.Value().width + j == room1.Value().width + i)
                {
                    solutions.Add(room2.Value().y + i);
                }
            }
        }

        if (random)
        {
            int location = solutions[Random.Range(0, solutions.Count)];
            game[room2.Value().width - 1, location].contents = "corridor";
            game[room2.Value().height - 2, location].contents = "corridor";
        }
        else
        {
            int location = solutions[(solutions.Count / 2) - 1];
            game[room2.Value().width - 1, location].contents = "corridor";
            game[room2.Value().height - 2, location].contents = "corridor";
        }
    }
    */

    void RenderGame()
    {
        for (int i = 0; i < rooms.Count; i++)
        {
            for (int j = 0; j < game.GetLength(0); j++)
            {
                for (int k = 0; k < game.GetLength(1); k++)
                {
                    if (j < rooms[i].width + rooms[i].positionX &&
                        j >= rooms[i].positionX &&
                        k < rooms[i].height + rooms[i].positionY &&
                        k >= rooms[i].positionY)
                    {
                        game[j, k].contents = "room";
                    }
                }
            }
        }
    }

    void PrintGame()
    {
        StringBuilder gameString = new StringBuilder();
        for (int i = 0; i < game.GetLength(0); i++)
        {
            StringBuilder line = new StringBuilder();
            for (int j = 0; j < game.GetLength(1); j++)
            {
                if(game[j, i].contents == "empty")
                {
                    line.Append("E ");
                }
                else if (game[j, i].contents == "room")
                {
                    line.Append("F ");
                }
                else if (game[j, i].contents == "corridor")
                {
                    line.Append("C ");
                }
            }
            gameString.AppendLine(line.ToString());
        }
        print(gameString.ToString());

        using (System.IO.StreamWriter file =
            new System.IO.StreamWriter(@"GeneratedDungeon.txt"))
        {
            file.WriteLine(gameString.ToString());
        }
    }




    //--------------

    //Binary Tree Stuff


    private void SplitVertical(BinaryTree<RectInt> treeToSplit, out BinaryTreeNode<RectInt> leftPart, out BinaryTreeNode<RectInt> rightPart)
    {
        leftPart = new BinaryTreeNode<RectInt>(new RectInt(0, 0, treeToSplit.Root().Value().width / 2, height));
        treeToSplit.Root().AddChild(leftPart);

        rightPart = new BinaryTreeNode<RectInt>(new RectInt(width / 2, 0, treeToSplit.Root().Value().width / 2, height));
        treeToSplit.Root().AddChild(rightPart);
    }
    private void SplitVertical(BinaryTreeNode<RectInt> nodeToSplit, out BinaryTreeNode<RectInt> leftPart, out BinaryTreeNode<RectInt> rightPart)
    {
        //print("Split vertical: " + nodeToSplit.Value().ToString());
        int leftPartitionX = nodeToSplit.Value().x;
        int leftPartitionY = nodeToSplit.Value().y;
        leftPart = new BinaryTreeNode<RectInt>(new RectInt(leftPartitionX, leftPartitionY, nodeToSplit.Value().width / 2, nodeToSplit.Value().height));
        nodeToSplit.AddChild(leftPart);


        int rightPartitionX = nodeToSplit.Value().x + nodeToSplit.Value().width / 2;
        int rightPartitionY = nodeToSplit.Value().y;
        rightPart = new BinaryTreeNode<RectInt>(new RectInt(rightPartitionX, rightPartitionY, nodeToSplit.Value().width / 2, nodeToSplit.Value().height));
        nodeToSplit.AddChild(rightPart);
    }

    private void SplitHorizontal(BinaryTree<RectInt> treeToSplit, out BinaryTreeNode<RectInt> upPart, out BinaryTreeNode<RectInt> downPart)
    {
        upPart = new BinaryTreeNode<RectInt>(new RectInt(0, 0, width, height / 2));
        treeToSplit.Root().AddChild(upPart);

        downPart = new BinaryTreeNode<RectInt>(new RectInt(0, height / 2, width, height / 2));
        treeToSplit.Root().AddChild(downPart);
    }

    private void SplitHorizontal(BinaryTreeNode<RectInt> nodeToSplit, out BinaryTreeNode<RectInt> upPart, out BinaryTreeNode<RectInt> downPart)
    {
        //print("Split horizontal: " + nodeToSplit.Value().ToString());
        int upPartitionX = nodeToSplit.Value().x;
        int upPartitionY = nodeToSplit.Value().y;
        upPart = new BinaryTreeNode<RectInt>(new RectInt(upPartitionX, upPartitionY, nodeToSplit.Value().width, nodeToSplit.Value().height / 2));
        nodeToSplit.AddChild(upPart);

        int downPartitionX = nodeToSplit.Value().x;
        int downPartitionY = nodeToSplit.Value().y + nodeToSplit.Value().height / 2;
        downPart = new BinaryTreeNode<RectInt>(new RectInt(downPartitionX, downPartitionY, nodeToSplit.Value().width, nodeToSplit.Value().height / 2));
        nodeToSplit.AddChild(downPart);
    }

    private void Subdivide(BinaryTreeNode<RectInt> nodeToSplit, bool vertical, int subdivisions)
    {
        if (vertical)
        {
            BinaryTreeNode<RectInt> upPart;
            BinaryTreeNode<RectInt> downPart;
            SplitVertical(nodeToSplit, out upPart, out downPart);
            subdivisions--;
            if (subdivisions > 0)
            {
                Subdivide(upPart, !vertical, subdivisions);
                Subdivide(downPart, !vertical, subdivisions);
            }
            else
            {
                partitions.Add(new Partition(upPart.Value().width, upPart.Value().height, upPart.Value().x, upPart.Value().y));
                partitions.Add(new Partition(downPart.Value().width, downPart.Value().height, downPart.Value().x, downPart.Value().y));
                if (nodeToSplit.leftChild == null && nodeToSplit.rightChild == null)
                {
                    nodeToSplit.AddChild(upPart);
                    nodeToSplit.AddChild(downPart);
                }
            }
        }
        else
        {
            BinaryTreeNode<RectInt> leftPart;
            BinaryTreeNode<RectInt> rightPart;
            SplitHorizontal(nodeToSplit, out leftPart, out rightPart);
            subdivisions--;


            if (subdivisions > 0)
            {
                Subdivide(leftPart, !vertical, subdivisions);
                Subdivide(rightPart, !vertical, subdivisions);
            }
            else
            {
                partitions.Add(new Partition(leftPart.Value().width, leftPart.Value().height, leftPart.Value().x, leftPart.Value().y));
                partitions.Add(new Partition(rightPart.Value().width, rightPart.Value().height, rightPart.Value().x, rightPart.Value().y));
                if (nodeToSplit.leftChild == null && nodeToSplit.rightChild == null)
                {
                    nodeToSplit.AddChild(leftPart);
                    nodeToSplit.AddChild(rightPart);
                }
            }
        }
    }

    private void Subdivide(BinaryTree<RectInt> nodeToSplit, bool vertical, int subdivisions)
    {
        if (vertical)
        {
            BinaryTreeNode<RectInt> upPart;
            BinaryTreeNode<RectInt> downPart;
            SplitVertical(nodeToSplit, out upPart, out downPart);
            subdivisions--;
            if (subdivisions > 0)
            {
                Subdivide(upPart, !vertical, subdivisions);
                Subdivide(downPart, !vertical, subdivisions);
            }
            else
            {
                partitions.Add(new Partition(upPart.Value().width, upPart.Value().height, upPart.Value().x, upPart.Value().y));
                partitions.Add(new Partition(downPart.Value().width, downPart.Value().height, downPart.Value().x, downPart.Value().y));
            }
        }
        else
        {
            BinaryTreeNode<RectInt> leftPart;
            BinaryTreeNode<RectInt> rightPart;
            SplitHorizontal(nodeToSplit, out leftPart, out rightPart);
            subdivisions--;
            if (subdivisions > 0)
            {
                Subdivide(leftPart, !vertical, subdivisions);
                Subdivide(rightPart, !vertical, subdivisions);
            }
            else
            {
                partitions.Add(new Partition(leftPart.Value().width, leftPart.Value().height, leftPart.Value().x, leftPart.Value().y));
                partitions.Add(new Partition(rightPart.Value().width, rightPart.Value().height, rightPart.Value().x, rightPart.Value().y));
            }
        }
    }

    private void MakeCorridors(BinaryTree<RectInt> tree)
    {
        CorridorsRecursiveDive(tree.Root().leftChild);
        CorridorsRecursiveDive(tree.Root().rightChild);
        if (ConnectHorizontal(tree.Root().leftChild, tree.Root().rightChild, false))
        {
            print("connected");
        }
        else
        {
            ConnectVertical(tree.Root().leftChild, tree.Root().rightChild, false);
        }
    }

    private void CorridorsRecursiveDive(BinaryTreeNode<RectInt> node)
    {
        if (node.leftChild != null)
        {
            CorridorsRecursiveDive(node.leftChild);
            if(ConnectHorizontal(node.leftChild, node.rightChild, false))
            {
                print("connected");
            }
            else
            {
                ConnectVertical(node.leftChild, node.rightChild, false);
            }
        }
        if (node.rightChild != null)
        {
            CorridorsRecursiveDive(node.rightChild);
            if (ConnectHorizontal(node.leftChild, node.rightChild, false))
            {
                print("connected");
            }
            else
            {
                ConnectVertical(node.leftChild, node.rightChild, false);
            }
        }
    }

    private RectInt NodeRectWorld(BinaryTreeNode<RectInt> node)
    {
        BinaryTreeNode<RectInt> current = node;
        RectInt rectWorld = node.Value();
        rectWorld.x = 0;
        rectWorld.y = 0;
        while (current != null)
        {
            rectWorld.x += current.Value().x;
            rectWorld.y += current.Value().y;

            current = current.parent;
        }
        return rectWorld;
    }


}
