﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

public class FileSaveHardContent : MonoBehaviour {

	// Use this for initialization
	void Start () {
        System.Text.StringBuilder contentBuilder = new System.Text.StringBuilder();

        contentBuilder.AppendLine("E E E E E E");
        contentBuilder.AppendLine("E F F E E E");
        contentBuilder.AppendLine("E F F E E E");
        contentBuilder.AppendLine("E C C E E E");
        contentBuilder.AppendLine("E C C E E E");
        contentBuilder.AppendLine("E F F E E E");
        contentBuilder.AppendLine("E E E E E E");

        string content = contentBuilder.ToString();

        File.WriteAllText("C:\\temp\\sample.bspd", content);
    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
