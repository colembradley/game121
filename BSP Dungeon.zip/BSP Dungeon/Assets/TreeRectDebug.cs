﻿using Assets;
using UnityEngine;

public class TreeRectDebug : MonoBehaviour {

    public int levelWidth = 20;
    public int levelHeight = 20;

    void Start() {
        BinaryTree<RectInt> sampleRectTree;
        sampleRectTree = new BinaryTree<RectInt>(new RectInt(0, 0, levelWidth, levelHeight));

        //int partitionWidth = levelWidth / 2;
        //int partitionHeight = levelHeight;
        //RectInt leftPartitionRect = new RectInt(0, 0, partitionWidth, partitionHeight);
        //BinaryTreeNode<RectInt> leftPartitionNode = sampleRectTree.Root().AddChild(leftPartitionRect);
        //
        //int rightPartitionX = levelWidth / 2;
        //int rightPartitionY = 0;
        //RectInt rightPartitionRect = new RectInt(rightPartitionX, rightPartitionY, partitionWidth, levelHeight);
        //BinaryTreeNode<RectInt> rightPartitionNode = sampleRectTree.Root().AddChild(rightPartitionRect);

        BinaryTreeNode<RectInt> leftPartitionNode;
        BinaryTreeNode<RectInt> rightPartitionNode;

        //BinaryTreeNode<RectInt> leftLeftPartitionNode;
        //BinaryTreeNode<RectInt> leftRightPartitionNode;

        BinaryTreeNode<RectInt> leftUpPartitionNode;
        BinaryTreeNode<RectInt> leftDownPartitionNode;
        BinaryTreeNode<RectInt> rightUpPartitionNode;
        BinaryTreeNode<RectInt> rightDownPartitionNode;

        SplitVertical(sampleRectTree, out leftPartitionNode, out rightPartitionNode);
        SplitHorizontal(leftPartitionNode, out leftUpPartitionNode, out leftDownPartitionNode);
        SplitHorizontal(rightPartitionNode, out rightUpPartitionNode, out rightDownPartitionNode);

        RectInt leftPartitionWorld = NodeRectWorld(leftPartitionNode);
        RectInt rightPartitionWorld = NodeRectWorld(rightPartitionNode);

        RectInt rightDownPartitionWorld = NodeRectWorld(rightDownPartitionNode);
        RectInt rightUpPartitionWorld = NodeRectWorld(rightUpPartitionNode);
        RectInt leftDownPartitionWorld = NodeRectWorld(leftDownPartitionNode);
        RectInt leftUpPartitionWorld = NodeRectWorld(leftUpPartitionNode);

        print("Left: " + leftPartitionWorld);
        print("Right: " + rightPartitionWorld);

        //print("Left: " + leftLeftPartitionWorld);
        //print("Right: " + leftRightPartitionWorld);

        print("Left Up: " + leftUpPartitionWorld);
        print("Left Down: " + leftDownPartitionWorld);

        print("Right Up: " + rightUpPartitionWorld);
        print("Right Down: " + rightDownPartitionWorld);

    }

    private void SplitVertical(BinaryTree<RectInt> tree, out BinaryTreeNode<RectInt> leftPart, out BinaryTreeNode<RectInt> rightPart)
    {
        int leftPartitionX = 0;
        int leftPartitionY = 0;
        leftPart = new BinaryTreeNode<RectInt>(new RectInt(leftPartitionX, leftPartitionY, tree.Root().Value().width/2, levelHeight));
        tree.Root().AddChild(leftPart.Value());

        int rightPartitionX = levelWidth / 2;
        int rightPartitionY = 0;
        rightPart = new BinaryTreeNode<RectInt>(new RectInt(rightPartitionX, rightPartitionY, tree.Root().Value().width/2, levelHeight));
        tree.Root().AddChild(rightPart.Value());
    }
    private void SplitVertical(BinaryTreeNode<RectInt> nodeToSplit, out BinaryTreeNode<RectInt> leftPart, out BinaryTreeNode<RectInt> rightPart)
    {
        int leftPartitionX = 0;
        int leftPartitionY = nodeToSplit.Value().x;
        leftPart = new BinaryTreeNode<RectInt>(new RectInt(leftPartitionX, leftPartitionY, nodeToSplit.Value().width / 2, nodeToSplit.Value().height));
        nodeToSplit.AddChild(leftPart.Value());

        int rightPartitionX = nodeToSplit.Value().width / 2;
        int rightPartitionY = 0;
        rightPart = new BinaryTreeNode<RectInt>(new RectInt(rightPartitionX, rightPartitionY, nodeToSplit.Value().width / 2, nodeToSplit.Value().height));
        nodeToSplit.AddChild(rightPart.Value());
    }

    private void SplitHorizontal(BinaryTreeNode<RectInt> nodeToSplit, out BinaryTreeNode<RectInt> upPart, out BinaryTreeNode<RectInt> downPart)
    {
        int upPartitionX = nodeToSplit.Value().x;
        int upPartitionY = nodeToSplit.Value().y;
        upPart = new BinaryTreeNode<RectInt>(new RectInt(upPartitionX, upPartitionY, nodeToSplit.Value().width, nodeToSplit.Value().height / 2));
        nodeToSplit.AddChild(upPart.Value());

        int downPartitionX = nodeToSplit.Value().x;
        int downPartitionY = nodeToSplit.Value().height/2;
        downPart = new BinaryTreeNode<RectInt>(new RectInt(downPartitionX, downPartitionY, nodeToSplit.Value().width, nodeToSplit.Value().height / 2));
        nodeToSplit.AddChild(downPart.Value());
    }

    private RectInt NodeRectWorld(BinaryTreeNode<RectInt> node)
    {
        BinaryTreeNode<RectInt> current = node;
        RectInt rectWorld = node.Value();
        rectWorld.x = 0;
        rectWorld.y = 0;
        while (current != null)
        {
            rectWorld.x += current.Value().x;
            rectWorld.y += current.Value().y;

            current = current.parent;
        }
        return rectWorld;
    }
	
	void Update () {
		
	}
}
