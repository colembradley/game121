﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Assets;

public class treeDebug : MonoBehaviour {

	void Start () {
        BinaryTree<int> sampleTree = new BinaryTree<int>(42);

        BinaryTreeNode<int> left = sampleTree.Root().AddChild(5);
        BinaryTreeNode<int> right = sampleTree.Root().AddChild(17);

        BinaryTreeNode<int> leftOfLeft = left.AddChild(-6);
        BinaryTreeNode<int> rightOfLeft = left.AddChild(12);

        BinaryTreeNode<int> leftOfRight = right.AddChild(128);
        BinaryTreeNode<int> rightOfRight = right.AddChild(1024);

        BinaryTreeNode<int> treeRoot = sampleTree.Root();
        List<BinaryTreeNode<int>> leaves = new List<BinaryTreeNode<int>>();

        CollectLeaves(treeRoot, leaves);

        foreach (BinaryTreeNode<int> leaf in leaves)
        {
            print("Leaf found with value " + leaf.Value() + " and parent value " + leaf.parent.Value());
            int currentLeafSum = CountFromNodeToRoot(leaf);
            print("Sum to root is " + currentLeafSum);
        }

        //int leftOfLeftSum = CountFromNodeToRoot(leftOfLeft);
        //int rightOfLeftSum = CountFromNodeToRoot(rightOfLeft);
        //int leftOfRightSum = CountFromNodeToRoot(leftOfRight);
        //int rightOfRightSum = CountFromNodeToRoot(rightOfRight);
        //
        //print(leftOfLeftSum);
        //print(rightOfLeftSum);
        //print(leftOfRightSum);
        //print(rightOfRightSum);
    }

    private void CollectLeaves(BinaryTreeNode<int> currentNode, List<BinaryTreeNode<int>> leaves)
    {
        if (currentNode == null) return;

        if(currentNode.IsLeaf())
        {
            leaves.Add(currentNode);
        }
        else
        {
            CollectLeaves(currentNode.leftChild, leaves);
            CollectLeaves(currentNode.rightChild, leaves);
        }
    }

    private int CountFromNodeToRoot(BinaryTreeNode<int> startNode)
    {
        BinaryTreeNode<int> current = startNode;
        int totalValue = 0;

        while (current != null)
        {
            totalValue += current.Value();
            current = current.parent;
        }

        return totalValue;
    }
}
