﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovingObstacle : MonoBehaviour {

    public float moveSpeed = 3.0f;
    public bool move = false;
	void Update () {
        if (move)
        {
            GetComponent<Rigidbody>().velocity = new Vector3(moveSpeed * Time.deltaTime*100, 0f, 0f);
        }
        else
        {
            GetComponent<Rigidbody>().velocity = Vector3.zero;
        }
	}
}
