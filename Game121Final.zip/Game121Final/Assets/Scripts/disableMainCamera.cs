﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class disableMainCamera : MonoBehaviour {

    public bool hasWon = false;
	void Update () {
        if (!hasWon)
        {
            if(GameObject.FindGameObjectsWithTag("Coin").Length == 0)
            {
                hasWon = true;
                GetComponent<sendPlayerToLocation>().enabled = false;
                GetComponent<movingObstacleInput>().enabled = false;
            }
        }
	}
}
