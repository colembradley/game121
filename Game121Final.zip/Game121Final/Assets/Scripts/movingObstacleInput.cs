﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class movingObstacleInput : MonoBehaviour {

    public bool movingObject = false;
    private MovingObstacle lastObstacle;

    void Update()
    {
        if (Input.GetKey(KeyCode.Space))
        {
            RaycastHit hit;
            if (Physics.Raycast(GetComponent<Camera>().ScreenPointToRay(Input.mousePosition), out hit, 1000))
            {
                if (hit.collider.gameObject.tag == "Obstacle")
                {
                    lastObstacle = hit.collider.gameObject.GetComponent<MovingObstacle>();
                    lastObstacle.move = true;
                    movingObject = true;
                }
            }
        }
        else if(movingObject)
        {
            movingObject = false;
            lastObstacle.move = false;
            lastObstacle.moveSpeed = -lastObstacle.moveSpeed;
        }
    }
}
