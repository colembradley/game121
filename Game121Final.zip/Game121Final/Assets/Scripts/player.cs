﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class player : MonoBehaviour
{

    public float moveSpeed;
    public float gravity;
    public float satisfactionRadius = 5.0f;

    public bool seekTargetSet = false;

    private Rigidbody rigidbody;
    private Vector3 target;

    void Start()
    {
        rigidbody = GetComponent<Rigidbody>();
    }

    void Update()
    {
        Vector3 moveDir = Vector3.zero;

        //Apply gravity
        Vector3 gravityMagnitude = Vector3.zero;
        gravityMagnitude.y -= gravity * Time.deltaTime * 100;
        rigidbody.velocity = (gravityMagnitude);

        if (seekTargetSet)
        {
            moveDir = target - transform.position;
            float distance = Vector3.Distance(target, transform.position);
            //Satisfation Radius
            if (distance <= satisfactionRadius)
            {
                seekTargetSet = false;
            }
        }

        //Move
        Move(moveDir);
        //Face
        transform.rotation = Quaternion.LookRotation(moveDir);
    }

    public void Seek(Vector3 position)
    {
        target = position;
        target.y = transform.position.y;
        seekTargetSet = true;
    }

    private void Move(Vector3 moveDir)
    {
        rigidbody.velocity += (moveDir.normalized * moveSpeed * Time.deltaTime * 100);
    }
}