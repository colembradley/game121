﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class sendPlayerToLocation : MonoBehaviour
{

    public player player;

    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            RaycastHit hit;
            if (Physics.Raycast(GetComponent<Camera>().ScreenPointToRay(Input.mousePosition), out hit, 1000))
            {
                if (hit.collider.gameObject.layer == 8)
                {
                    player.Seek(hit.point);
                }
            }
        }
    }
}
