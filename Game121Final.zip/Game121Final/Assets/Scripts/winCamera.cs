﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class winCamera : MonoBehaviour {

    public bool hasWon = false;
    void Update()
    {
        if (!hasWon)
        {
            if (GameObject.FindGameObjectsWithTag("Coin").Length == 0)
            {
                hasWon = true;
                transform.GetChild(0).gameObject.SetActive(true);
            }
        }
    }
}
