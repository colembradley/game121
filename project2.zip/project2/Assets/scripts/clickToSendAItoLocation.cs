﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class clickToSendAItoLocation : MonoBehaviour {

    public kinematicCore controlledAI;

	void Update () {
        if (Input.GetMouseButtonDown(0))
        {
            RaycastHit hit;
            if(Physics.Raycast(GetComponent<Camera>().ScreenPointToRay(Input.mousePosition), out hit, 1000, 1 << LayerMask.NameToLayer("floor")))
            {
                if(Input.GetKey(KeyCode.LeftAlt) || Input.GetKey(KeyCode.RightAlt))
                {
                    controlledAI.Flee(hit.point);
                }
                else
                {
                    controlledAI.Seek(hit.point);
                }
            }
        }
	}
}
