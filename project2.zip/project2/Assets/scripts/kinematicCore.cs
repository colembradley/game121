﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class kinematicCore : MonoBehaviour {

    public float moveSpeed;
    public float gravity;
    private float realMoveSpeed;
    public float satisfactionRadius = 5.0f;
    public float approachRadius = 15.0f;

    public bool seekTargetSet = false;
    private bool fleeTargetSet = false;

    private CharacterController characterController;
    private Vector3 target;

    void Start () {
        characterController = GetComponent<CharacterController>();
	}
	
	void Update () {
        realMoveSpeed = moveSpeed;
        Vector3 moveDir = Vector3.zero;

        //Apply gravity
        Vector3 gravityMagnitude = Vector3.zero;
        gravityMagnitude.y -= gravity * Time.deltaTime;
        characterController.Move(gravityMagnitude);

        if (seekTargetSet)
        {
            moveDir = target - transform.position;
            float distance = Vector3.Distance(target, transform.position);
            //Satisfation Radius
            if (distance <= satisfactionRadius)
            {
                seekTargetSet = false;
            }
            //Arive
            if (distance <= approachRadius)
            {
                realMoveSpeed = (distance / approachRadius) * moveSpeed;
            }
        }
        else if (fleeTargetSet)
        {
            moveDir = transform.position - target;
        }

        //Move
        Move(moveDir);
        //Face
        transform.rotation = Quaternion.LookRotation(moveDir);
    }

    public void Seek(Vector3 position)
    {
        target = position;
        target.y = transform.position.y;
        seekTargetSet = true;
        fleeTargetSet = false;
    }

    public void Flee(Vector3 position)
    {
        target = position;
        target.y = transform.position.y;
        fleeTargetSet = true;
        seekTargetSet = false;
    }

    private void Move(Vector3 moveDir)
    {
        characterController.Move(moveDir.normalized * realMoveSpeed * Time.deltaTime);
    }
}
