﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class patrollingHumanoid : MonoBehaviour {

    kinematicCore kinematicCore;
    public waypointController waypointController;

    public Transform target;

    private bool useRaycast = true;
    public float raycastLength;
    public float attackRadius;
    public LayerMask playerDetectionLayers;

    public int health = 100;
    public int projectileDamage = 5;

    public bool dead = false;

    bool seek;
    bool isSeeking;
    bool attack;

    public float attackTime = 3.0f;
    public float runSpeed = 10f;

    public GameObject projectile;
    public float projectileSpeed;
    private Vector3 projectileDir;
    public Transform projectileSpawn;

    void Start()
    {
        target = GameObject.Find("Player").transform;
        kinematicCore = GetComponent<kinematicCore>();
    }

    void Update()
    {

        if (!dead)
        {
            if (useRaycast)
            {
                Vector3 raycastDir = target.transform.position - transform.position;
                RaycastHit hit;
                Debug.DrawRay(transform.position, raycastDir.normalized * raycastLength, Color.blue);
                if (Physics.Raycast(transform.position, raycastDir, out hit, raycastLength, playerDetectionLayers.value))
                {
                    seek = true;
                }
                Debug.DrawRay(transform.position, raycastDir.normalized * attackRadius, Color.red);
                if (Physics.Raycast(transform.position, raycastDir, out hit, attackRadius, playerDetectionLayers.value))
                {
                    if (!attack)
                    {
                        StartCoroutine(Attack());
                    }
                }
            }

            if (seek)
            {
                kinematicCore.Seek(target.position);
                if (!isSeeking)
                {
                    isSeeking = true;
                    kinematicCore.moveSpeed = runSpeed;
                    GetComponent<Animator>().SetBool("run", true);
                    waypointController.enabled = false;
                }
            }
        }

        //Die
        if (health <= 0 && !dead)
        {
            dead = true;
            kinematicCore.enabled = false;
            GetComponent<CharacterController>().enabled = false;
            GetComponent<Animator>().SetTrigger("die");
        }
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "projectile")
        {
            health -= projectileDamage;
            GetComponent<AudioSource>().Play();
            if (!seek)
            {
                seek = true;
            }
        }
    }

    IEnumerator Attack()
    {
        attack = true;
        kinematicCore.enabled = false;
        GetComponent<Animator>().SetBool("attack", true);

        yield return new WaitForSeconds(attackTime/2.5f);

        //fire projectile
        projectileDir = transform.forward;
        GameObject clone = Instantiate(projectile, projectileSpawn.position, projectileSpawn.rotation);
        clone.GetComponent<Rigidbody>().AddForce(projectileDir * projectileSpeed);

        yield return new WaitForSeconds(attackTime/1.5f);

        attack = false;
        kinematicCore.enabled = true;
        GetComponent<Animator>().SetBool("attack", false);
    }
}
