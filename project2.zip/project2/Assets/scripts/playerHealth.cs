﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerHealth : MonoBehaviour {

    public int health = 100;
    public int projectileDamage = 5;
    public bool dead = false;
    public thirdPersonCamera cameraScript;
    public GameObject deathCamera;
    public clickToTeleport teleportScript;
    public GameObject healthSound;

    public int healthPackAmount = 50;

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "evilBlastRadius")
        {
            health -= projectileDamage;
            GetComponent<AudioSource>().Play();
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "health")
        {
            if (!dead)
            {
                health += 50;
                Destroy(other.transform.parent.gameObject);
                var clone = Instantiate(healthSound, transform.position, Quaternion.identity);
                Destroy(clone, 2f);
            }
        }
    }

    void Update()
    {
        //Die
        if (health <= 0 && !dead)
        {
            dead = true;
            cameraScript.enabled = false;
            teleportScript.enabled = false;
            deathCamera.SetActive(true);
            gameObject.SetActive(false);
        }
    }
}
