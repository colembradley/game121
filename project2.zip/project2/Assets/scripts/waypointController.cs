﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class waypointController : MonoBehaviour {

    public Transform waypointTrack;
    private List<Transform> waypointList = new List<Transform>();
    public kinematicCore controller;
    private int currentWaypoint = 0;

    void Start()
    {
        foreach (Transform child in waypointTrack)
        {
            waypointList.Add(child);
        }
        controller.Seek(waypointList[0].transform.position);
    }

    void Update () {
        if (!controller.seekTargetSet)
        {
            if(currentWaypoint == waypointList.Count-1)
            {
                currentWaypoint = 0;
            }
            else
            {
                currentWaypoint++;
            }
            controller.Seek(waypointList[currentWaypoint].transform.position);
        }
	}
}
